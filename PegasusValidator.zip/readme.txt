Prüft IPhones ab Version 6S auf den gefährliche Pegasus Trojaner Dieser Scanner erkennt 99% aller Pegasus Viren und Trojaner mit ähnlichen Signaturen. Pegasus Validator ist KOSTENLOS.

Was ist Pegasus? Es handelt sich um einen besonders gefährlichen Trojaner, welches sich in Systemdateien absetzt. Dieser ist so aggressiv, dass über 50% aller IPhones 6S - IPhone XS MAX mit Pegasus infiziert wurden. Dieser Trojaner erlaubt das ausspähen von Daten, geheimes aktivieren der Kamera und nachinstallieren von Schadsoftware.

Berichte: https://www.heise.de/hintergrund/iPhones-selbst-auf-Pegasus-und-andere-Spyware-pruefen-6143960.html https://www.heise.de/news/NSO-Skandal-100-Organisationen-fordern-Verkaufsstopp-fuer-Spyware-6149195.html https://www.heise.de/news/Sicherheitsforscher-Apple-tut-nicht-genug-fuer-die-Sicherheit-seiner-Nutzer-6146740.html https://www.heise.de/news/Bugfix-und-Security-Updates-fuer-Mac-iPhone-und-iPad-6148246.html

Anleitung:

Stecken Sie ihr IPhone an Ihren Mac oder Windows Computer.
Starten Sie PegasusValidator.jar.
Warten Sie, bis der Scan abgeschlossen ist.
Sollten keine Warnungen erscheinen, haben Sie mit hoher Wahrscheinlichkeit kein manipuliertes Gerät.

Bekante apps, welche von Pegasus infiziert waren
PhotoBooth, FaceTune, Instagram, SunshineSmile, WhatsApp, Facebook Business, Snapchat Downloader

Warnung
Sollte eine Warnung erscheinen, gehen Sie wie folgt vor:

Aktivieren Sie die iCloud auf Ihrem Gerät falls noch nicht geschehen. Einstellungen -> iCloud -> Alles aktivieren.
Starten Sie die Fotos App und prüfen, ob alle Daten synchronisiert sind.
Rufen Sie https://www.icloud.com/photos/ auf und prüfen ob Ihre Daten vorhanden sind.
Entfernen sie sämtliche Apps, die Sie nicht benötigen.
Stellen Sie Gerät auf Werkseinstellungen zurück.
Aktivieren Sie nach dem Neustart die iCloud auf Ihrem Gerät.
Installieren Sie https://apps.apple.com/de/app/mobile-security-wlan-vpn/id724596345 und lassen einen Scan durchlaufen
Entfernen Sie die App und installieren zukünftig keine Apps mehr von Fremdquellen.